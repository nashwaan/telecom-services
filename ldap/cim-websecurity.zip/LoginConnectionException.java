package com.etisalat.cim.websecurity;

public class LoginConnectionException extends Exception {
    public LoginConnectionException(String message) {
        super(message);
    }
}
