package com.etisalat.cim.websecurity;

public interface LdapConfigInt {
	LdapConfig getConfig();

	// void save(LdapConfig conf);
}
